######################
Como utilizar
######################
- Abrir "Rico.exe" (n�o tem instalador, abre direto);

- Initial path -> indica o caminho no qual queres procurar as m�quinas;
	ex.: dep_t�cnico\m�quinas\2017, se quiseres procurar s� nas m�quinas de 2017

- Abre o ficheiro "Parameters.txt" e procura os c�digos dos par�metros que queres procurar / criar m�dias;
	ex.: c�digo 1485 para identificar o par�metro "Refer�ncia das ferramenta

- Adiciona todos os c�digos que quiseres pesquisar na lista "Parameters" do programa (tens que adicionar um a um);

- Se quiseres remover tens que primeiro selecionar;

- Indica o nome da m�quina ou alguma palavra chave que v� aparecer no caminho do ficheiro. Por norma ser� o nome
  da m�quina, mas podes querer dar outro crit�rio de pesquisa;
	ex.: "2017" para pesquisar s� nas pastas que contenham este texto, iria pesquisar s� nas m�quinas de 2017

- "Collect parameters" vai correr o programa e gerar o ficheiro excel com as m�dias dos par�metros


######################
Vers�es de ficheiros
######################
Este programa n�o � compativel com as vers�es "n�o-OK".
N�o vai gerar nenhum erro, esses ficheiros v�o simplestemente ser ignorados

Vers�es OK
- V2.3.8
- V2.3.13
- V2.4.13
- V2.5.1
- V2.5.9
(e possivelmente todas as mais recentes)

Vers�es n�o-OK
- V2.2.10
(e possivelmente todas as anteriores)



#############################################
Ficheiros necess�rios para o programa correr
#############################################
� necess�rio existir na pasta, a partir da qual o programa est� a ser executado, entre outros, um ficheiro 'modelo' "machineparameters.txt" (tem que se chamar "Parameters.txt" podes usar este que j� est� nesta pasta) para servir de modelo para o programa trabalhar.

Este ficheiro tem que ser de uma das vers�es "OK".

Para verificar a vers�o do ficheiro - abrir o ficheiro e verificar na primeira linha - "Vers�o DA on Windows".



################################
Par�metros dos eixos auxiliares
################################
Os eixos auxiliares t�m os mesmos c�digo para os par�metros que s�o comuns.
Por exemplo, n�o � possivel distinguir, para cada um dos eixos (X1/X2/R1/...), o par�metro
- Nome: "Veloc man. alta"
- C�digo: "1090"

Ao iniciar "Collect Parameters", o programa vai verificar os par�metros que foram inseridos. Por defeito, os par�metros encontrados em duplicado, v�o ser ignorados.