Estes dois ficheiros s�o criados automaticamente (se ainda n�o existirem) na mesma pasta onde o programa est� a correr. Se os apagares vais perder os logs e as m�dias que tinhas, mas o programa funciona na mesma.

parameters_values.csv -> Ficheiro onde os as m�dias s�o gravadas

output_log.txt -> Ficheiro de log, se tiveres problemas podes-me enviar este ficheiro para eu tentar perceber de onde o problema vem.

machinepaths.txt -> Ficheiro onde s�o guardados os caminhos para os ficheiros das m�quinas. Este ficheiro � reescrito sempre que fazes um novo c�lculo de m�dias.