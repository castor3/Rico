﻿namespace FSharp_refactorings

type LPToken = XiNone | XiEqu | XiInf | XiSup | XiDiff | XiSupEqu | XiInfEqu | XiMatch | XiIn | XiOr | XiAdd | XiSub | XiNot | XiAnd | XiMul | XiDiv | XiDivI | XiMod | XiSepar | XiIf | XiDecode | XiFor | XiLen | XiEval | XiDistinct | XiSum | XiMax | XiMin | XiAbs | XiSubstring | XiSearch | XiContains | XiLength | XiJoin | XiIDF | XiConst | XiCall | XiParL | XiParR | XiBracketL | XiBracketR | XiCurlyL | XiCurlyR | XiNull | XiTrue | XiFalse | XiToday | XiEnd
