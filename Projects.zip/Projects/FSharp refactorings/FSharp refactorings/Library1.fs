﻿namespace FSharp_refactorings

module LPLex =
    open System

    let source = "string with formula"
    let data:string = null

    let takeIdfWithDelim = 1 + 1
    
    let mutable currentPosition = 0

    let nextChar = source.Chars(currentPosition + 1)

    let currentChar = if currentPosition < source.Length
                        then source.Chars(currentPosition)
                        else Char.MaxValue

    let handleCrochet = 
        // Data = TakeIdfWithDelim();
        LPToken.XiIDF
    let handleMinorSign =
        // Cenas
        LPToken.XiNone
    let handleGreaterSign =
        // Cenas
        LPToken.XiNone
    let handleChainDelimiters =
        // Cenas
        LPToken.XiConst
    let hanleDateDelimiter =
        // Cenas
        LPToken.XiConst

    let handleIsDigit =
        // Cenas
        LPToken.XiConst

    let handleIsChar =
        // Cenas
        LPToken.XiNone
    
    let MakeError =
        //Cenas
        LPToken.XiNone

    let handleDefault currentChar =
        if Char.IsDigit(currentChar)
            then handleIsDigit
            else if Char.IsLetter(currentChar) || currentChar.Equals('_')
                    then handleIsChar
                    else MakeError

    let tokenMatcher char = 
        match char with
        |';' |',' -> LPToken.XiSepar
        |'+' -> LPToken.XiAdd
        |'-' -> LPToken.XiSub
        |'/' -> LPToken.XiDiv
        |'(' -> LPToken.XiParL
        |')' -> LPToken.XiParR
        |']' -> LPToken.XiBracketR
        |'{' -> LPToken.XiCurlyL
        |'}' -> LPToken.XiCurlyR
        |'=' -> LPToken.XiEqu
        |'*' -> LPToken.XiMul
        |'[' -> handleCrochet
        |'<' -> handleMinorSign
        |'>' -> handleGreaterSign
        |'"' |'\'' -> handleChainDelimiters
        |'!' -> hanleDateDelimiter
        |_ -> handleDefault(char)

    let nextToken = tokenMatcher currentChar