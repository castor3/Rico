﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.ServiceModel;
using System.Web.Services;
using Newtonsoft.Json;
using Otb.LoggingFramework.Client.RestServiceReference;
using Otb.LoggingFramework.ServiceContracts;

namespace Otb.LoggingFramework.Client
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Client started...");

			var serviceData = new ServiceData
			{
				System = "MacOS",
				ClientMachine = "Intel",
				User = "Rui",
				//Date = DateTimeOffset.Now,
				//Tags = new List<string> { "OK", "Sophis" }
			};

			//var httpCient = new HttpClient();

			//httpCient.BaseAddress = new Uri("http://localhost:8080/WinService/RestService/");
			//httpCient.DefaultRequestHeaders.Accept.Clear();
			//httpCient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			//var response = httpCient.PostAsJsonAsync("json", serviceData).Result;
			//response.EnsureSuccessStatusCode();
			//serviceData = response.Content.ReadAsAsync<ServiceData>().Result;




			//var jsonData = JsonConvert.SerializeObject(serviceData);

			var service = new RestServiceClient("ClientEndpoint");

			Console.WriteLine("Endpoint name = " + service.Endpoint.Name);

			var newData = service.SendDataAsJSON(serviceData);

			//if (success)
			//{
			//	Console.WriteLine("Data sent successfully");
			//}
			//else
			//{
			//	Console.WriteLine("Failed to send data");
			//}

			Console.WriteLine("System = " + newData.ClientMachine);
			Console.Read();





			//MemoryStream stream = new MemoryStream();
			//var objectSerializer = new DataContractJsonSerializer(typeof(ServiceData));
			//objectSerializer.WriteObject(stream, serviceData);
			//string data = Encoding.UTF8.GetString(stream.ToArray(), 0, (int)stream.Length);

			//var webClient = new WebClient();
			//webClient.Headers["Content-Type"] = "application/json";
			//webClient.Encoding = Encoding.UTF8;

			//var response = webClient.UploadString(@"http://localhost:8080/ServiceLibrary/RestService/json", data);
			//Console.WriteLine($"Response = {response}");
			/*
						Console.WriteLine($"JSON call -> {service.SendDataAsJSON("12345")}");
						Console.Read();
						Console.WriteLine($"XML call -> {service.XMLData("54321")}");

						var serviceData = new ServiceData
						{
							System = "MacOS",
							ClientMachine = "Intel",
							User = "Rui",
							Date = DateTimeOffset.Now,
							Tags = new string[] { "OK", "Sophis" }
						};

						var jsonData = JsonConvert.SerializeObject(serviceData);

						var success = service.SendDataAsJSON(jsonData);

						if (success)
						{
							Console.WriteLine("Data sent successfully");
						}
						else
						{
							Console.WriteLine("Failed to send data");
						}

			*/
		}
	}
}
