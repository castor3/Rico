﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace Otb.LoggingFramework.WinService
{
	[RunInstaller(true)]
	public partial class WindowsServiceInstaller : Installer
	{
		private ServiceProcessInstaller _processInstaller;
		private ServiceInstaller _installer;

		public WindowsServiceInstaller()
		{
			AfterInstall += new InstallEventHandler(AutoStart);

			_processInstaller = new ServiceProcessInstaller { Account = ServiceAccount.LocalSystem };
			_installer = new ServiceInstaller { ServiceName = "Demo Service", Description = "WCF Service on Windows Service", DelayedAutoStart = true, StartType = ServiceStartMode.Automatic };

			Installers.AddRange(new Installer[] { _processInstaller, _installer });
		}
		private void AutoStart(object sender, InstallEventArgs e)
		{
			using (var sc = new ServiceController(_installer.ServiceName))
			{
				sc.Start();
			}
		}
	}
}
