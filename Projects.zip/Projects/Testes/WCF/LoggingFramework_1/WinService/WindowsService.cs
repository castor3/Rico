﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceProcess;
using Otb.LoggingFramework.ServiceContracts;

namespace Otb.LoggingFramework.WinService
{
	public partial class WindowsService : ServiceBase
	{
		private ServiceHost _serviceHost = null;
		public WindowsService()
		{
			InitializeComponent();
		}

		public void onDebug()
		{
			OnStart(null);
		}

		protected override void OnStart(string[] args)
		{
			if (_serviceHost != null)
			{
				_serviceHost.Close();
			}

			_serviceHost = new ServiceHost(typeof(RestService));
			//_serviceHost = new ServiceHost(typeof(RestService), new Uri("http://localhost:8080/"));
			//var serviceEndpoint = _serviceHost.AddServiceEndpoint(typeof(IRestService), new WebHttpBinding(), "ServiceLibrary/RestService");
			//serviceEndpoint.Behaviors.Add(new WebHttpBehavior());
			_serviceHost.Open();
		}

		protected override void OnStop()
		{
			if (_serviceHost == null)
			{
				return;
			}

			_serviceHost.Close();
			_serviceHost = null;
		}
	}
}
