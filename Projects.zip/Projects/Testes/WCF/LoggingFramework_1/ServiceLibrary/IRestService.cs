﻿using System.ServiceModel;
using System.ServiceModel.Web;

namespace Otb.LoggingFramework.ServiceContracts
{
	// Contract rules
	[ServiceContract]
	public interface IRestService
	{
		[OperationContract]
		[WebInvoke(Method = "POST", UriTemplate = "/json")]
		ServiceData SendDataAsJSON(ServiceData data);

		[OperationContract]
		[WebGet(UriTemplate = "/cenas/{data}")]
		string XMLData(string data);
	}
}
