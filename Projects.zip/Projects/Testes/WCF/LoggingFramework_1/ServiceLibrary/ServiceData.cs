﻿using System.Runtime.Serialization;

namespace Otb.LoggingFramework.ServiceContracts
{
	[DataContract(Name = "servicedata", Namespace = "")]
	public class ServiceData
	{
		[DataMember(Name = "system", Order = 1)]
		public string System { get; set; }

		[DataMember(Name = "clientmachine", Order = 2)]
		public string ClientMachine { get; set; }

		[DataMember(Name = "user", Order = 3)]
		public string User { get; set; }

		[DataMember(Name = "message", Order = 4)]
		public string Message { get; set; }

		[DataMember(Name = "data", Order = 5)]
		public string Data { get; set; }

		//[DataMember(Name = "date", Order = 6)]
		//public DateTime Date { get; set; }
/*
		[DataMember]
		public List<string> Tags { get; set; }*/
	}
}
