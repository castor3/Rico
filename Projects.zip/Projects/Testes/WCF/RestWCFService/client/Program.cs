﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.Win32;
using WCFContracts;

namespace client
{
    class Program
    {
        static  void Main(string[] args)
        {
			Console.Write("Press any key to start the client...");
            Console.ReadKey();
            var httpCient = new HttpClient();

            httpCient.BaseAddress = new Uri("http://localhost:64195/Hosting/");
            httpCient.DefaultRequestHeaders.Accept.Clear();
            httpCient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var user = new User();
            user.FirstName = "first name";
            user.LastName = "other name";
            Console.WriteLine(user.UserId);
            HttpResponseMessage response = httpCient.PostAsJsonAsync("users", user).Result;
            response.EnsureSuccessStatusCode();

            user = response.Content.ReadAsAsync<User>().Result;
            Console.WriteLine(user.UserId);
            Console.ReadKey();

        }
    }
}
