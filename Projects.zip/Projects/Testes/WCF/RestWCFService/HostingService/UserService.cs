﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;
using WCFContracts;

namespace HostingService
{
    public class UserService : IUserService
    {
        public Users GetUsers()
        {
            Users users = new Users();
            users.Add(new User()
            {
                FirstName = "alik",
                LastName = "levin",
                Email = DateTime.Now,
                UserId = "1"
            });

            return users;
        }
        
        public User AddNewUser(User u)
        {
            u.UserId = Guid.NewGuid().ToString();
            return u;
        }
    }
}
