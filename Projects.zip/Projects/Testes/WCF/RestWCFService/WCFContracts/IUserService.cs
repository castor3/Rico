﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace WCFContracts
{
    [ServiceContract]
	public interface IUserService
    {
		[WebGet(UriTemplate = "/users")]
		[OperationContract]
		Users GetUsers();

		[WebInvoke(UriTemplate = "/users", Method = "POST")]
		[OperationContract]
		User AddNewUser(User u);
    }
}
