﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplication1.TestServiceReference;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
			var client = new ServiceInterfaceClient();
			Console.WriteLine("Client started...");
			var composite = new CompositeType();
			var result = client.GetData(composite);
			Console.WriteLine($"GetData result = '{result.StringValue}'");
			Console.Read();
			client.Close();
		}
	}
}
