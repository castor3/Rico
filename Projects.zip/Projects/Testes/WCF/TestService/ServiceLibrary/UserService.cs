﻿using System;
using System.ServiceModel;
using System.ServiceModel.Web;
using ConsoleApp;

namespace ServiceLibrary
{
	[ServiceContract]
	public class UserService
	{
		static Users _users = new Users();

		[WebGet(UriTemplate = "/users")]
		[OperationContract]
		public Users GetAllUsers()
		{
			GenerateFakeUsers();
			return _users;
		}

		[WebInvoke(UriTemplate = "/users", Method = "POST")]
		[OperationContract]
		public User AddNewUser(User u)
		{
			u.UserId = Guid.NewGuid().ToString();
			_users.Add(u);
			return u;
		}

		[WebGet(UriTemplate = "/users/{user_id}")]
		[OperationContract]
		public User GetUser(string user_id)
		{
			var u = FindUser(user_id);
			return u;
		}

		private User FindUser(string user_id)
		{
			return new User()
			{
				FirstName = "alik",
				LastName = "levin",
				Email = "alikl@microsoft.com",
				UserId = "1"
			};
		}

		private void GenerateFakeUsers()
		{
			_users.Add(new User()
			{
				FirstName = "alik",
				LastName = "levin",
				Email = "alikl@microsoft.com",
				UserId = "1"
			});
		}
	}
}
