﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace WinService
{
	[RunInstaller(true)]
	public partial class WindowsServiceInstaller : Installer
	{
		private ServiceProcessInstaller _processInstaller;
		private ServiceInstaller _installer;

		public WindowsServiceInstaller()
		{
			_processInstaller = new ServiceProcessInstaller { Account = ServiceAccount.LocalSystem };
			_installer = new ServiceInstaller { ServiceName = "Demo Service", Description = "WCF Service with Windows Service", DelayedAutoStart = true };
			Installers.AddRange(new Installer[] { _processInstaller, _installer });
		}
	}
}
