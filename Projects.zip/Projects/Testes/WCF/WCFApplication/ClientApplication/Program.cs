﻿using System;
using ServiceLibrary;

namespace ClientApplication
{
	class Program
	{
		static void Main(string[] args)
		{
			var service = new RestService();
			Console.WriteLine($"JSON call -> {service.JSONData("12345")}");
			Console.Read();
			Console.WriteLine($"XML call -> {service.XMLData("54321")}");
			Console.Read();
			Console.Read();
		}
	}
}
