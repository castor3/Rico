﻿namespace ServiceLibrary
{
	public class RestService : IRestService
	{
		public string JSONData(string id)
		{
			return $"JSON data id = {id}";
		}

		public string XMLData(string id)
		{
			return $"XML data id = {id}";
		}
	}
}
