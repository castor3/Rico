﻿using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace ServiceLibrary
{
	// Contract rules
	[ServiceContract]
	public interface IRestService
	{
		[OperationContract]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "json/{id}")]
		string JSONData(string id);

		[OperationContract]
		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "xml/{id}")]
		string XMLData(string id);
	}

	// Data members
	//[DataContract]
	//public class DataClass
	//{
	//	[DataMember]
	//	public bool BoolMember { get; set; }

	//	[DataMember]
	//	public string StringMember { get; set; }
	//}
}
