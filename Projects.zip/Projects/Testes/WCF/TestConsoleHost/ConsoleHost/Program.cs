﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleHost
{
	class Program
	{
		static void Main(string[] args)
		{
			ServiceBase[] ServicesToRun;
			ServicesToRun = new ServiceBase[]
			{
				new WindowsService()
			};
			ServiceBase.Run(ServicesToRun);

			//using (var host = new ServiceHost(typeof(TestService.Service)))
			//{
			//	host.Open();
			//	Console.WriteLine("Host started...");
			//	Console.Read();
			//}
		}
	}
}
