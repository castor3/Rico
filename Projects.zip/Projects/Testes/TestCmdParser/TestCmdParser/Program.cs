﻿using System;
using CommandLine;

namespace TestCmdParser
{
	class Program
	{
		static void Main(string[] args)
		{
			var parseResult = Parser.Default.ParseArguments<Options>(args);

			Func<Options> onError = () => null;

			var options = parseResult.MapResult(
							(values) => new Options { Configuration = values.Configuration, Output = values.Output },
							_ => onError());

			if (options == null)
			{
				return;
			}

			Console.WriteLine($"Config = {options.Configuration}");
			Console.WriteLine($"Output = {options.Output}");
		}
	}
}
