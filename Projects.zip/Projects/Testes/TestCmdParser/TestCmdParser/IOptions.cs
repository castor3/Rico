﻿using CommandLine;

namespace TestCmdParser
{
	interface IOptions
	{
		[Option('c', "configuration", Required = true, HelpText = "File with configuration settings")]
		string Configuration { get; set; }

		[Option('o', "output", Required = true, HelpText = "File with output data")]
		string Output { get; set; }
	}
}
