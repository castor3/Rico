﻿using System.Collections.Generic;
using CommandLine.Text;

namespace TestCmdParser
{
	class Options : IOptions
	{
		public string Configuration { get; set; }

		public string Output { get; set; }

		[Usage(ApplicationAlias = "TestCmdParser.exe")]
		public static IEnumerable<Example> Examples
		{
			get
			{
				yield return new Example("Example", new Options { Configuration = "config file", Output = "output file" });
			}
		}

	}
}
