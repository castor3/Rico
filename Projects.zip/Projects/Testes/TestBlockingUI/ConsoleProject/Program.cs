﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace BlockedUI
{
	public class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Application started");

			Console.WriteLine("Will run first");
			DoSomethingLong();

			Console.WriteLine("Moving to second");

			Console.WriteLine("Will run second");
			DoOtherThing();

			Console.WriteLine("Moving to 'Read'");

			Console.Read();
		}

		private static async void DoSomethingLong()	// 'async' tells the rest of the program that it doesn't have to wait for this method
		{
			Console.WriteLine("## First started ##");
			await Task.Run(() =>	// Sets up a new thread that will run the code below
			{
				for (int i = 1; i <= 20; i++)
				{
					Thread.Sleep(1000);
					Console.WriteLine($"First:	#{i} of {20} --");
				}
				Console.WriteLine("## First finished ##");
			});
		}

		private static void DoOtherThing()
		{
			Console.WriteLine("## Second started ##");
			for (int i = 1; i <= 10; i++)
			{
				Thread.Sleep(500);
				Console.WriteLine($"Second:	#{i} of {10}");
			}
			Console.WriteLine("## Second finished ##");
		}
	}
}
