﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace UI
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public List<string> Output { get; set; } = new List<string>();

		public MainWindow()
		{
			InitializeComponent();

			//while (true)
			//{
			//	ListViewOutput.ItemsSource = Output;
			//}
		}

		private void BtnStart_Click(object sender, RoutedEventArgs e)
		{
			Output.Add("Application started");

			Output.Add("Will run first");
			DoSomethingLong();

			Output.Add("Moving to second");

			Output.Add("Will run second");
			DoOtherThing();

			Output.Add("Moving to 'Read'");
		}

		private async void DoSomethingLong() // 'async' tells the rest of the program that it doesn't have to wait for this method
		{
			Output.Add("## First started ##");
			await Task.Run(() =>    // Sets up a new thread that will run the code below
			{
				for (int i = 1; i <= 20; i++)
				{
					Thread.Sleep(1000);
					//Output.Add($"First:	#{i} of 20 --");
				}
				//Output.Add("## First finished ##");
			});
		}

		private void DoOtherThing()
		{
			Output.Add("## Second started ##");
			for (int i = 1; i <= 10; i++)
			{
				Thread.Sleep(500);
				//Output.Add($"Second:	#{i} of 10"); ListViewOutput.ItemsSource = Output;
			}
			Output.Add("## Second finished ##");
		}
		private void SetStatusBarTimer()
		{//  DispatcherTimer setup
			var timer = new DispatcherTimer();
			timer.Tick += StatusBarTimer_Tick;
			timer.Interval = new TimeSpan(0, 0, 0, 2, 500);
			timer.Stop();
			timer.Start();
		}
		private void StatusBarTimer_Tick(object sender, EventArgs e)
		{
			var timer = (DispatcherTimer)sender;
			timer.Stop();
		}
	}
}
