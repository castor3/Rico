﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Otb.LoggingFramework.ServiceContracts
{
	[DataContract]
	public class ServiceData
	{
		[DataMember]
		public string System { get; set; }

		[DataMember]
		public string ClientMachine { get; set; }

		[DataMember]
		public string User { get; set; }

		[DataMember]
		public string Message { get; set; }

		[DataMember]
		public string Data { get; set; }

		//[DataMember(Name = "date", Order = 6)]
		//public DateTime Date { get; set; }

		[DataMember]
		public List<string> Tags { get; set; }

	}
}
