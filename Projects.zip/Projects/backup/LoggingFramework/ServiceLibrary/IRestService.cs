﻿using System.ServiceModel;
using System.ServiceModel.Web;

namespace Otb.LoggingFramework.ServiceContracts
{
	[ServiceContract]
	public interface IRestService
	{
		[OperationContract]
		[WebInvoke(Method = "POST", UriTemplate = "/json")]
		ServiceData SendDataAsJSON(ServiceData data);

		[OperationContract]
		[WebGet(UriTemplate = "/xml/{value}")]
		string XMLData(string value);
	}
}
