﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Otb.LoggingFramework.ServiceLibrary;

namespace Client2
{
	class Program
	{
		static void Main(string[] args)
		{

			Console.WriteLine("Client started...");

			var serviceData = new ServiceData
			{
				System = "MacOS",
				ClientMachine = "Intel",
				User = "Rui",
				//Date = DateTime.Now,
				//Tags = new List<string> { "OK", "Sophis" }
			};

			var httpCient = new HttpClient();

			httpCient.BaseAddress = new Uri("http://localhost:64195/Hosting/");
			httpCient.DefaultRequestHeaders.Accept.Clear();
			httpCient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

			var response = httpCient.PostAsJsonAsync("json", serviceData).Result;
			response.EnsureSuccessStatusCode();
			serviceData = response.Content.ReadAsAsync<ServiceData>().Result;
			Console.WriteLine("System = " + serviceData.ClientMachine);
			Console.Read();

		}
	}
}
