﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Otb.LoggingFramework.ServiceContracts;

namespace Otb.LoggingFramework.Client
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Client started...");

			var serviceData = new ServiceData
			{
				System = "MacOS",
				ClientMachine = "Intel",
				User = "Rui",
				//Date = DateTimeOffset.Now,
				Tags = new List<string> { "OK", "Sophis" }
			};

			var httpCient = new HttpClient();
			httpCient.BaseAddress = new Uri("http://localhost:8080");
			httpCient.DefaultRequestHeaders.Accept.Clear();
			httpCient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			Console.WriteLine("'HttpClient()' started...");

			Console.WriteLine("Old -> ClientMachine = " + serviceData.ClientMachine);

			var response = httpCient.PostAsJsonAsync("json", serviceData).Result;
			response.EnsureSuccessStatusCode();
			serviceData = response.Content.ReadAsAsync<ServiceData>().Result;
			
			Console.WriteLine("New -> ClientMachine = " + serviceData.ClientMachine);
			Console.Read();
		}
	}
}
