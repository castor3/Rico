﻿using System.ServiceModel;
using System.ServiceProcess;

namespace Otb.LoggingFramework.WinService
{
	public partial class WindowsService : ServiceBase
	{
		private ServiceHost _serviceHost = null;
		public WindowsService()
		{
			InitializeComponent();
		}

		public void onDebug()
		{
			OnStart(null);
		}

		protected override void OnStart(string[] args)
		{
			if (_serviceHost != null)
			{
				_serviceHost.Close();
			}

			_serviceHost = new ServiceHost(typeof(RestService));
			_serviceHost.Open();
		}

		protected override void OnStop()
		{
			if (_serviceHost == null)
			{
				return;
			}

			_serviceHost.Close();
			_serviceHost = null;
		}
	}
}
