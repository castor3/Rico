﻿using System.ServiceProcess;

namespace Otb.LoggingFramework.WinService
{
	static class Program
	{
		static void Main()
		{
			ServiceBase[] ServicesToRun;
			ServicesToRun = new ServiceBase[]
			{
				new WindowsService()
			};
			ServiceBase.Run(ServicesToRun);
		}
	}
}
