﻿using Otb.LoggingFramework.ServiceContracts;

namespace Otb.LoggingFramework.WinService
{
	public class RestService : IRestService
	{
		public ServiceData SendDataAsJSON(ServiceData data)
		{
			data.ClientMachine = "machinecenas";
			return data;
		}

		public string XMLData(string incomingData)
		{
			return $"XML = {incomingData}";
		}
	}
}
