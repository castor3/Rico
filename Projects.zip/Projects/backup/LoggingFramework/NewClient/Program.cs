﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewClient
{
	class Program
	{
		static void Main(string[] args)
		{
			var client = new RestServiceReference.RestServiceClient();
			Console.WriteLine("Client started...");
			var data = new RestServiceReference.servicedata();
			var result = client.SendDataAsJSON(data);
			Console.WriteLine($"Result of method call = '{result.clientmachine}'");
			Console.Read();
			client.Close();
		}
	}
}
