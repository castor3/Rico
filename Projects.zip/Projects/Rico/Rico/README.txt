######################
Vers�es de ficheiros
######################
Este programa n�o � compativel com as vers�es "n�o-OK".
N�o vai gerar nenhum erro, mas os valores desses ficheiros n�o v�o ser utilizados para fazer as m�dias

Vers�es OK
- V2.3.8
- V2.3.13
- V2.4.13
- V2.5.1
- V2.5.9
(e possivelmente todas as mais recentes)

Vers�es n�o-OK
- V2.2.10
(e possivelmente todas as anteriores)



#############################################
Ficheiros necess�rios para o programa correr
#############################################
� necess�rio existir na pasta, a partir da qual o programa est� a ser executado, entre outros, um ficheiro 'modelo' "machineparameters.txt" para servir de modelo para o programa trabalhar.

Este ficheiro tem que ser de uma das vers�es "OK".

Para verificar a vers�o do ficheiro - abrir o ficheiro e verificar na primeira linha - "Vers�o DA on Windows".



################################
Par�metros dos eixos auxiliares
################################
Os eixos auxiliares t�m os mesmos c�digo para os par�metros que s�o comuns.
Por exemplo, n�o � possivel distinguir, para cada um dos eixos (X1/X2/R1/...), o par�metro
- Nome: "Veloc man. alta"
- C�digo: "1090"

Ao iniciar "Collect Parameters", o programa vai verificar os par�metros que foram inseridos. Por defeito, os par�metros encontrados em duplicado, v�o ser ignorados.

# H� eixos auxiliares (ou opcionais como "LaserSafe") que n�o est�o ativos em algumas m�quinas.
# Se tentar procurar por par�metros desses eixos, em ficheiros de m�quinas que n�o os continham, esses par�metros v�o ser ignorados e o programa vai prosseguir normalmente.


