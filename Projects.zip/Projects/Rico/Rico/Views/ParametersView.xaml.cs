﻿using System.Windows;

namespace Rico.Views
{
    /// <summary>
    /// Interaction logic for SearchParametersView.xaml
    /// </summary>
    public partial class ParametersView
    {
        public ParametersView()
        {
            InitializeComponent();
        }
    }
}
