# SupportFiles
Project to generate a .dll that contains commonly used functions/methods
