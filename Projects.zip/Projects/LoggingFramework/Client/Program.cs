﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using Otb.LoggingFramework.Dto;

namespace Otb.LoggingFramework.Client
{
	class Program
	{
		static void Main(string[] args)
		{
			var option = 0;
			HttpClient httpCient = null;
			while (true)
			{
				Console.Write("'LoggingFramework' client started..." + Environment.NewLine +
							  "1 - List DB content" + Environment.NewLine +
							  "2 - Add log data to DB" + Environment.NewLine +
							  "3 - List logs received today" + Environment.NewLine +
							  "0 - Exit" + Environment.NewLine +
							  "Option: ");

				if (!int.TryParse(Console.ReadLine(), out option))
				{
					Console.WriteLine("Invalid option, pls try again");
					continue;
				}

				if (option == 0) return;

				httpCient = CreateHttpClient();
				if (httpCient == null)
				{
					Console.WriteLine("Failed to start new HttpClient");
					continue;
				}

				Console.WriteLine("'HttpClient()' started...");

				if (option == 1) ListDBContent();
				if (option == 2) AddLogToDB();
				if (option == 3) ListTodaysLogs();
			}

			//Console.WriteLine("Old -> ClientMachine = " + logData.ClientMachine);

			//Console.WriteLine("New -> ClientMachine = " + logData.ClientMachine);
		}

		private static LogDataDto PostJsonDataAsync(HttpClient httpCient, LogDataDto logData)
		{
			var response = httpCient.PostAsJsonAsync("json", logData).Result;
			response.EnsureSuccessStatusCode();
			return response.Content.ReadAsAsync<LogDataDto>().Result;
		}

		private static List<LogDataDto> ListTodaysLogs()
		{
			Console.WriteLine(nameof(ListTodaysLogs));
			return new List<LogDataDto>();
		}

		private static void AddLogToDB()
		{
			Console.WriteLine(nameof(AddLogToDB) + ":");
			var logData = new LogDataDto
			{
				System = "MacOS",
				ClientMachine = "Intel",
				User = "Rui",
				//Date = DateTimeOffset.Now,
				Tags = new List<string> { "OK", "Sophis" }
			};
			Console.WriteLine("log data created...");
		}

		private static void ListDBContent()
		{
			Console.WriteLine(nameof(ListDBContent));
		}

		private static HttpClient CreateHttpClient()
		{
			Console.WriteLine("Creating HttpClient...");
			var httpCient = new HttpClient();
			httpCient.BaseAddress = new Uri("http://localhost:8080");
			httpCient.DefaultRequestHeaders.Accept.Clear();
			httpCient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
			return httpCient;
		}
	}
}
