﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Otb.LoggingFramework.Dto
{
	[DataContract]
	public class LogDataDto
	{
		[DataMember]
		public string System { get; set; }

		[DataMember]
		public string ClientMachine { get; set; }

		[DataMember]
		public string User { get; set; }

		[DataMember]
		public string Message { get; set; }

		[DataMember]
		public string Data { get; set; }

		//[DataMember(Name = "date", Order = 6)]
		//public DateTime Date { get; set; }

		[DataMember]
		public IList<string> Tags { get; set; }

	}
}
