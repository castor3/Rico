﻿using Otb.LoggingFramework.Dto;
using Otb.LoggingFramework.WinService.Contracts;

namespace Otb.LoggingFramework.WinService
{
	public class RestService : IRestService
	{
		public LogDataDto SendDataAsJSON(LogDataDto data)
		{
			data.ClientMachine = "machinecenas";
			return data;
		}

		public string XMLData(string incomingData)
		{
			return $"XML = {incomingData}";
		}
	}
}
