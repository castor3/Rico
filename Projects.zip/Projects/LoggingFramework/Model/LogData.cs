﻿using System;
using System.Collections.Generic;

namespace Otb.LoggingFramework.Model
{
	public class LogData
    {
		public int Id { get; set; }

		public string System { get; set; }

		public string ClientMachine { get; set; }

		public string User { get; set; }

		public string Message { get; set; }

		public string Data { get; set; }

		public DateTime Date { get; set; }

		public IList<string> Tags { get; set; }
	}
}
