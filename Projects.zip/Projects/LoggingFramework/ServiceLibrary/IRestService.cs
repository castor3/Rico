﻿using System.ServiceModel;
using System.ServiceModel.Web;
using Otb.LoggingFramework.Dto;

namespace Otb.LoggingFramework.WinService.Contracts
{
	[ServiceContract]
	public interface IRestService
	{
		[OperationContract]
		[WebInvoke(Method = "POST", UriTemplate = "/json")]
		LogDataDto SendDataAsJSON(LogDataDto data);

		[OperationContract]
		[WebGet(UriTemplate = "/xml/{value}")]
		string XMLData(string value);
	}
}
