﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Otb.LoggingFramework.Model;

namespace Otb.LoggingFramework.DatabaseLibrary
{
	class LogDBInitializer : CreateDatabaseIfNotExists<LogDataContext>
	{
		List<LogData> _loggingData = new List<LogData>();

		public LogDBInitializer()
		{
			_loggingData.Add(new LogData { Id = 1 });
			_loggingData.Add(new LogData { Id = 2 });
			_loggingData.Add(new LogData { Id = 3 });
			_loggingData.Add(new LogData { Id = 4 });
			_loggingData.Add(new LogData { Id = 5 });
		}
	}
}
