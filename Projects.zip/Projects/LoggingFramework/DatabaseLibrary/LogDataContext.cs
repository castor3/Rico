﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Otb.LoggingFramework.Dto;
using Otb.LoggingFramework.WinService.Contracts;

namespace Otb.LoggingFramework.DatabaseLibrary
{
	public class LogDataContext : DbContext
	{
		public LogDataContext() : base("LogData")
		{
			Database.SetInitializer(new LogDBInitializer());
		}

		public DbSet<LogDataDto> LogData { get; set; }

		public DbSet<List<string>> Tags { get; set; }

	}
}
